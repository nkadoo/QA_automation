package restApi;

import java.net.URISyntaxException;
import org.json.JSONException;
import org.testng.Assert;
import org.testng.annotations.Test;
import utility.Utility;


public class RestTest {

	private static String HAYATT_AUTIN = "HYATT AUSTIN";
	private static String API_URL = "https://api.data.gov/nrel/alt-fuel-stations/v1/nearest.json?api_key=pREiRd43YrqtipuUXEqofzDxpuEDu4xkyrCCJIsz&location=Austin+TX";
	private static String API_URL1 = "https://api.data.gov/nrel/alt-fuel-stations/v1/";
	
	@Test
	public void getStationName() throws JSONException, URISyntaxException {
		
		String jsonCityName = Utility.getStationName(API_URL, RestTest.HAYATT_AUTIN);
		
		Assert.assertEquals(jsonCityName, RestTest.HAYATT_AUTIN);
	}
	
	@Test
	public void getStationId() throws JSONException, URISyntaxException {
		
		String jsonStationId = Utility.getStationId(API_URL, RestTest.HAYATT_AUTIN);
		String apiURLWithCityId = API_URL1 + jsonStationId + ".json?api_key=pREiRd43YrqtipuUXEqofzDxpuEDu4xkyrCCJIsz";
		String jsonResponseAddress = Utility.getSreetAddress(apiURLWithCityId);
		
		Assert.assertEquals("208 Barton Springs Rd", jsonResponseAddress);
		
	}
	
}
