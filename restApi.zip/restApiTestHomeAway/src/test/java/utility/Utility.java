package utility;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class Utility {
	
	public static JSONObject getJsonObject(String URL) {
		Client client = Client.create();

		WebResource webResource = client
		   .resource(URL);

		ClientResponse response = webResource.accept("application/json")
                   .get(ClientResponse.class);

		if (response.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "
			+ response.getStatus());
		}
		
		String output = response.getEntity(String.class);
		//System.out.println(output);

		JSONObject jsonObject = new JSONObject(output);
		
		return jsonObject;
	}
	
	public static String getStationId(String URL, String city) {
		JSONObject dataObject = Utility.getJsonObject(URL);
		JSONArray jsonArr = (JSONArray) dataObject.get("fuel_stations");
		String stationId = "";

	    for(int i=0; i<jsonArr.length(); i++){
	    	
	    	if(jsonArr.getJSONObject(i).getString("ev_network").equalsIgnoreCase("ChargePoint Network") &&
	    			jsonArr.getJSONObject(i).getString("station_name").equalsIgnoreCase(city)){
	    		stationId = jsonArr.getJSONObject(i).get("id").toString();
	    	}
	    }
	    return stationId;
	}
	
	public static String getStationName(String URL, String city) {
		JSONObject dataObject = Utility.getJsonObject(URL);
		JSONArray jsonArr = (JSONArray) dataObject.get("fuel_stations");
		String stationName = "";

	    for(int i=0; i<jsonArr.length(); i++){
	    	
	    	if(jsonArr.getJSONObject(i).getString("ev_network").equalsIgnoreCase("ChargePoint Network") &&
	    			jsonArr.getJSONObject(i).getString("station_name").equalsIgnoreCase(city)){
	    		stationName = jsonArr.getJSONObject(i).getString("station_name").toString();
	    	}
	    }
	    return stationName;
	}

	public static String getSreetAddress(String URL) {
		JSONObject dataObject = Utility.getJsonObject(URL);
		JSONObject dataAltFuelStation = dataObject.getJSONObject("alt_fuel_station");
		
	    return dataAltFuelStation.get("street_address").toString();
	}

}
